﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyHW3.Models;
using Newtonsoft.Json;
using System.IO.Compression;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;

namespace MyHW3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StationLiveBoardController : ControllerBase
    {
        private readonly Tokenbuild _tokenbuild;

        private readonly string apiUri = $"https://tdx.transportdata.tw/api/basic/v3/Rail/TRA/StationLiveBoard?$format=JSON";

        public StationLiveBoardController(Tokenbuild tokenbuild)
        {
            _tokenbuild = tokenbuild;
        }

        private Dictionary<string, string> GetParameters()
        {
            return new Dictionary<string, string>()
            {
                { $"$select","" },
                { $"$filter",""},
                { $"$orderby","stationID"},
                { $"$top",""},
                { $"$skip",""},
                { $"health",""},
                { $"$format","JSON"},
            };
        }


       
        [HttpGet]
        public  LiveBoard Get()
        {
            var accessToken = _tokenbuild.GetToken(_tokenbuild.tokenUri).Result;
           // ViewBag.AccessToken = accessToken.access_token;

            var apiResponse = _tokenbuild.Get(GetParameters(), apiUri, accessToken.access_token).Result;
            //ViewBag.ApiResponse = apiResponse;


            return JsonConvert.DeserializeObject<LiveBoard>(apiResponse); ;
        }
      
        


    }
}
